from flask import Flask, render_template, request, jsonify, session
from flask_session import Session
import psycopg2
import jwt
from uuid import uuid4
from router import router  

app = Flask(__name__)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = str(uuid4())
Session(app)


# SIGNUP PAGE
@app.route("/signup")
def signup():
    return render_template('signup')

# LOGIN PAGE
@app.route("/login")
def login():
    return render_template('login')

# LOGIN (get a token)
@app.route('/auth', methods=['GET'])
def authenticate():
    username = request.args.get('username')
    password = request.args.get('password')

    try:
        cursor = pool.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        verify = cursor.fetchone()

        if verify is None:
            return jsonify(f"There is no user with the username {username}")

        stored_password = verify[1]

        if password == stored_password:
            user = {
                'username': username,
                'pw': password
            }
            token = jwt.encode({'user': user}, 'secretkey', algorithm='HS256').decode('utf-8')
            session['token'] = token  # Store token in session
            return jsonify({'token': token})
        else:
            return jsonify(f"Password for user {username} is incorrect")

    except Exception as e:
        print(str(e))
        return jsonify("Error occurred during authentication")

    finally:
        cursor.close()

# REGISTER
@app.route('/register', methods=['POST'])
def register():
    username = request.json.get('username')
    password = request.json.get('password')

    try:
        cursor = pool.cursor()
        cursor.execute("INSERT INTO users(username, pw) VALUES (%s, %s)", (username, password))
        pool.commit()
        return jsonify(f"User {username} added successfully.")
    except Exception as e:
        print(str(e))
        return jsonify("Error occurred during registration")

    finally:
        cursor.close()

# THE BASE
@app.route("/")
def base():
    return render_template('base')

if __name__ == "__main__":
    app.run(debug=True)
