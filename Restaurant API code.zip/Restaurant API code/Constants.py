RESTAURANT_LIST = "restaurantsList"
MENU_LIST = "menusList"
FOOD_LIST = "foodsList"
