import os,sys
sys.path.append('../') 
import unittest
from urllib import response as rs, request as rq
from flask_testing import LiveServerTestCase
from run import create_app
from model import db, redis_cache
from config import PresentConfig

basedir = os.path.abspath(os.path.dirname(__file__))

class TestBaseCase(LiveServerTestCase):

    render_templates = False

    def create_app(self):
        self.app = create_app(PresentConfig)
        self.client = self.app.test_client()
        with self.app.app_context():
            db.init_app(self.app)
            redis_cache.init_app(self.app)
            db.create_all()
            db.session.commit()
        return self.app

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_base_food_endPoint(self):
        response = rq.urlopen(self.get_server_url() + "/api/foods")
        self.assertEqual(response.code, 200)

    def test_base_restaurant_endPoint(self):
        response = rq.urlopen(self.get_server_url() + "/api/restaurants")
        self.assertEqual(response.code, 200)

    def test_base_menu_endPoint(self):
        response = rq.urlopen(self.get_server_url() + "/api/menus")
        self.assertEqual(response.code, 200)



if __name__ == '__main__':
    unittest.main()

