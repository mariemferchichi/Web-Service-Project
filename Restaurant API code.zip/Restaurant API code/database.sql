CREATE DATABASE WebServiceProject 


CREATE TABLE restaurants(
id integer,
name string); 

CREATE TABLE users(
username string,
password string);

CREATE TABLE menus(
id integer,
name string,
restaurantId string); 

CREATE TABLE Food(
id integer,
name string,
description string,
creationDate timestamp,
restaurantId string,
menuId string); 