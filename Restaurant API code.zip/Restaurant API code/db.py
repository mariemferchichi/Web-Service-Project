import psycopg2
from psycopg2 import pool

# Define database connection parameters
db_params = {
    "user": "gyqhjwwg",
    "password": "olRD08yXC3tPEnG-2KoTv9tjEY42ELiW",
    "database": "xwnxumoi",
    "host": "arjuna.db.elephantsql.com",
    "port": 5432
}

# Create a PostgreSQL connection pool
connection_pool = psycopg2.pool.SimpleConnectionPool(
    minconn=1,
    maxconn=10,
    **db_params
)

# Function to get a connection from the pool
def get_connection():
    return connection_pool.getconn()

# Function to release a connection back to the pool
def release_connection(conn):
    connection_pool.putconn(conn)

# Function to close all connections in the pool
def close_all_connections():
    connection_pool.closeall()

# Example of using the connection pool
try:
    conn = get_connection()
    # Perform database operations using the connection

finally:
    # Release the connection back to the pool
    if conn:
        release_connection(conn)
