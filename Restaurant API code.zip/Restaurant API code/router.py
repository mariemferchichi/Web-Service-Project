from flask import Flask, request, jsonify, render_template, redirect, session
from flask_jwt import JWT, jwt_required
from flask_session import Session
import psycopg2
from uuid import uuid4

app = Flask(__name__)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = str(uuid4())
app.config['SESSION_COOKIE_SECURE'] = True  # For secure cookies over HTTPS
Session(app)

class User:
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

# Assuming you have already set up a PostgreSQL database and connection pool named 'pool'
# Replace the connection details with your own

def authenticate(username, password):
    try:
        cursor = pool.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        verify = cursor.fetchone()

        if verify is None:
            return None

        stored_password = verify[1]

        if password == stored_password:
            user = User(id=verify[0], username=username, password=password)
            return user

    except Exception as e:
        print(str(e))

    finally:
        cursor.close()

    return None

def identity(payload):
    user_id = payload['identity']
    try:
        cursor = pool.cursor()
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user_data = cursor.fetchone()

        if user_data is not None:
            user = User(id=user_data[0], username=user_data[1], password=user_data[2])
            return user

    except Exception as e:
        print(str(e))

    finally:
        cursor.close()

    return None

jwt = JWT(app, authenticate, identity)

# GLOBAL VARIABLES
token = None
userr = None
pww = None

# VERIFY TOKEN MIDDLEWARE
def verify_token(req, res, next):
    # get auth header value
    bearer_header = req.headers.get('authorization')

    # check if bearer is undefined
    if bearer_header:
        # split at the space
        bearer = bearer_header.split()

        # get token from array
        bearer_token = bearer[1]

        # set the token
        req.token = bearer_token

        # next middleware
        next()
    else:
        # forbidden
        res.status_code = 403
        return jsonify(message="Forbidden"), 403

# LOGIN
@app.route('/login', methods=['POST'])
def login():
    global token, userr, pww

    # get user
    username = request.json.get('username')
    password = request.json.get('password')

    try:
        cursor = pool.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        verify = cursor.fetchone()

        if verify is None:
            return jsonify(message=f"There is no user with the username {username}"), 404

        stored_password = verify[1]

        if password == stored_password:
            user = {
                'username': username,
                'pw': password
            }
            session['user'] = username
            userr = session['user']
            pww = password
            token = jwt.encode({'user': user}, 'secretkey', algorithm='HS256').decode('utf-8')
            return jsonify({'token': token}), 200
        else:
            return jsonify(message=f"Password for user {username} is incorrect"), 401

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred during login"), 500

    finally:
        cursor.close()

# SIGNUP
@app.route('/signup', methods=['POST'])
def signup():
    try:
        username = request.json.get('username')
        password = request.json.get('password')

        cursor = pool.cursor()
        cursor.execute("INSERT INTO users(username, pw) VALUES (%s, %s)", (username, password))
        pool.commit()

        return jsonify(message=f"User {username} added successfully."), 201

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred during registration"), 500

    finally:
        cursor.close()

# API
@app.route('/api')
def api():
    return render_template('api', token=token)

# BASE
@app.route('/base')
def base():
    return render_template('base')

# DASHBOARD
@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        return render_template('dashboard', user=session['user'])
    else:
        return "Unauthorized User", 401

# GET ALL RESTAURANTS
@app.route('/restaurants', methods=['GET'])
@jwt_required()
def get_restaurants():
    try:
        jwt.verify(req.token, 'secretkey')  

        cursor = pool.cursor()
        cursor.execute("SELECT * FROM restaurants")
        all_restaurants = cursor.fetchall()

        return jsonify(all_restaurants), 200

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred while fetching restaurants"), 500

    finally:
        cursor.close()

# REGISTER
@app.route('/register', methods=['POST'])
def register():
    try:
        username = request.json.get('username')
        password = request.json.get('password')

        cursor = pool.cursor()
        cursor.execute("INSERT INTO users(username, password) VALUES (%s, %s)", (username, password))
        pool.commit()

        return jsonify(message=f"User {username} added successfully."), 201

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred during registration"), 500

    finally:
        cursor.close()

# GET A restaurant
@app.route('//<name>', methods=['POST'])
@jwt_required()
def get_restaurant(name):
    try:
        jwt.verify(req.token, 'secretkey')  

        cursor = pool.cursor()
        cursor.execute("SELECT * FROM restaurants WHERE id = %s", [id1])
        restaurant = cursor.fetchone()

        if restaurant is None:
            return jsonify(message="This restaurant does not exist"), 404

        return jsonify(restaurant), 200

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred while fetching the restaurant"), 500

    finally:
        cursor.close()

# CREATE
@app.route('/restaurants', methods=['POST'])
@jwt_required()
def create_restaurant():
    try:
        jwt.verify(req.token, 'secretkey')  

        id = request.json.get('id')
        name = request.json.get('name')

        cursor = pool.cursor()
        cursor.execute("INSERT INTO restaurant (id, name) VALUES (%s, %s) RETURNING *", (id, name))
        new_restaurant = cursor.fetchone()

        return jsonify(new_restaurant), 201

    except Exception as e:
        print(str(e))
        return jsonify(message="Error occurred while creating a new restaurant"), 500

    finally:
        cursor.close()

# UPDATE
@app.route('/update', methods=['POST'])
@jwt_required()
def update_restaurant():
    try:
        jwt.verify(req.token, 'secretkey')  
        id = request.json.get
